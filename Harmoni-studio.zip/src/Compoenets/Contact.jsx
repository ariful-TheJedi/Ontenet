import React from 'react';
// import './ContactSection.css'; 

const Contact = () => {
  return (
    <section className="contact-section bg-black text-white py-5">
      <div className="container">
        {/* Logo and title section at the top */}
        <div className="d-flex flex-column align-items-center mb-4">
          <div className="d-flex align-items-center mb-2">
            <img 
              src="https://harmoniestudio.eu/media/pages/contact/ef8b5914ca-1756740094/harmonie_studio-logo.png" 
              alt="Harmonie Logo" 
              className="img-fluid harmonie-logo" 
            />
          </div>
          <hr className="bg-white harmonie-divider my-2" />
        </div>
        
        {/* Contact, Social, and Headquarter sections, now stacked vertically */}
        <div className="row flex-column">
          {/* Contacts section */}
          <div className="col mb-4">
            <h5 className="text-uppercase mb-3">Contacts</h5>
            <ul className="list-unstyled">
              <li className="mb-2">
                <a href="mailto:info@harmoniestudio.eu" className="text-white text-decoration-none">
                  info@harmoniestudio.eu
                </a>
              </li>
              <li>
                <a href="tel:+393332823292" className="text-white text-decoration-none">
                  +39 333 2823292
                </a>
              </li>
            </ul>
            <hr className="bg-white my-4" /> 
          </div>
          
          {/* Social section */}
          <div className="col mb-4">
            <h5 className="text-uppercase mb-3">Social</h5>
            <ul className="list-unstyled">
              <li className="mb-2">
                <a href="#" className="text-white text-decoration-none">Instagram</a>
              </li>
              <li className="mb-2">
                <a href="#" className="text-white text-decoration-none">Vimeo</a>
              </li>
              <li>
                <a href="#" className="text-white text-decoration-none">YouTube</a>
              </li>
            </ul>
            <hr className="bg-white my-4" /> 
          </div>
          
          {/* Headquarter section */}
          <div className="col mb-4">
            <h5 className="text-uppercase mb-3">Headquarter</h5>
            <p className="mb-0">Str. Calese, 31, 47891 Dogana, San Marino</p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;