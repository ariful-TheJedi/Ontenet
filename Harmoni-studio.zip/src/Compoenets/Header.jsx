import React from "react";

export default function Header() {
  return (
    <header className="fixed-bottom d-flex">
      <div className="logo d-flex justify-content-between align-items-center">
          <img src="https://attestdesign.com/wp-content/themes/ktad/img/logo-icon.png"/>
        <h5 className="text-white">H-Studio</h5>
      </div>
      <nav className="nav container d-flex mx-5 bg-light">
        <a href="#about" className="flex-fill text-decoration-none">
          About
        </a>
        <a href="#projects" className="flex-fill text-decoration-none">
          Projects
        </a>
        <a href="#contact" className="flex-fill text-decoration-none">
          Contact
        </a>
      </nav>
      <img src="https://harmoniestudio.eu/assets/brush/harmonie_studio-brush-desktop.png"/>
    </header>
  );
}
