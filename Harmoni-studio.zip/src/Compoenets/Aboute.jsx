import React from 'react';
// import './AboutUs.css'; // Import the stylesheet

const AboutUs = () => {
  return (
    <div className="about-us-container">
      {/* ======================= */}
      {/* About Section      */}
      {/* ======================= */}
      <section>
        <div className="about-us-sectionHeader">
          <h2>About</h2>
          <hr className="about-us-divider" />
        </div>

        <div className="about-us-content">
          <div className="about-us-leftColumn">
            {/* This SVG uses a filter to create the distorted brush stroke effect */}
            <svg className="about-us-brushStroke" viewBox="0 0 450 60" aria-hidden="true">
              <defs>
                <filter id="distort">
                  {/* Creates a turbulence "noise" map */}
                  <feTurbulence type="fractalNoise" baseFrequency="0.01 0.15" numOctaves="1" result="warp" />
                  {/* Uses the noise map to displace the pixels of the rectangle */}
                  <feDisplacementMap xChannelSelector="R" yChannelSelector="G" scale="30" in="SourceGraphic" in2="warp" />
                </filter>
              </defs>
              {/* The base shape that gets distorted by the filter */}
              <rect x="0" y="10" width="450" height="40" fill="white" filter="url(#distort)" />
            </svg>

            <div className="about-us-taglines">
              <p>Small Team, Big Vision.</p>
              <p>Deeply Visual Thinkers.</p>
              <p>We Work Fast & With Care.</p>
              <p>We Care About Aesthetics, Process and People.</p>
              <p>Fashion, Sport & Music Industry.</p>
              <p>Based in Rimini, Moving Across Milan, London and Beyond.</p>
            </div>
          </div>
          <div className="about-us-rightColumn">
            <p>
              HS is a creative team working with photography and video, combining digital and analog techniques to craft unique visuals. Our work tells stories with impact, balancing classic aesthetics and new technologies. A studio focused on shaping visual culture through images, motion, and direction.
            </p>
          </div>
        </div>
      </section>

      {/* ======================= */}
      {/* "What we do" Section  */}
      {/* ======================= */}
      <section className="about-us-whatWeDoSection">
        <div className="about-us-sectionHeader">
          <h2>What we do</h2>
          <hr className="about-us-divider" />
        </div>

        <div className="about-us-servicesList">
          <h1>Art Direction</h1>
          <h1>Creative Consultancy</h1>
          <h1>Content Creation</h1>
          <h1>Photography</h1>
          <h1>Production</h1>
        </div>
      </section>
    </div>
  );
};

export default AboutUs;