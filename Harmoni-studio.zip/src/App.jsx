import { useState } from 'react'
import Header from "./Compoenets/Header"

import './App.css'
import Contact from './Compoenets/Contact'
import Home from './Compoenets/Home'
import AboutUs from './Compoenets/Aboute'

function App() {

  return (
   <div className='H-studio'>
      <Header />
      <AboutUs/>
   </div>
  )
}

export default App
