import React from "react";
import "../assets/Publications.css"; // external CSS

// Reusable card component
const PublicationCard = ({ title, link, authors, journal, pubdate }) => {
  return (
    <div className="card">
      <h3>
        <a href={link}>{title}</a>
      </h3>
      <div className="authors">{authors}</div>
      <div className="journal">{journal}</div>
      <div className="pubdate">{pubdate}</div>
      <div className="actions">
        <a href="#">PDF</a>
        <a href="#">DOI</a>
        <a href="#">PubMed</a>
      </div>
    </div>
  );
};

// Main Publications component
const Publications = () => {
  return (
    <div className="container">
      <div className="title">
        <i className="fa-solid fa-book-medical"></i> Publications
      </div>

      <div className="timeline">
        {/* Year 2024 */}
        <div className="year">2024</div>

        {/* Left card */}
        <div className="left">
          <PublicationCard
            title="Renal Biomarkers: Novel Insights"
            link="#"
            authors={
              <>
                A. Ali, <span className="highlight">Prof. Dr. Mustafa Zaman</span>, S. Rahman
              </>
            }
            journal="Nephrology Today — Vol.18"
            pubdate="Published: Jan 12, 2024"
          />
        </div>
        <div className="center left">
          <span className="dot-left"></span>
        </div>
        <div className="right"></div>

        {/* Right card */}
        <div className="left"></div>
        <div className="center right">
          <span className="dot-right"></span>
        </div>
        <div className="right">
          <PublicationCard
            title="Interventional Techniques in AKI"
            link="#"
            authors={
              <>
                M. Chowdhury, <span className="highlight">Prof. Dr. Mustafa Zaman</span>
              </>
            }
            journal="Journal of Critical Nephrology — Vol.4"
            pubdate="Published: Feb 28, 2024"
          />
        </div>

        {/* Year 2023 */}
        <div className="year">2023</div>

        {/* Left card */}
        <div className="left">
          <PublicationCard
            title="Effect of Treatment X on Kidney Function"
            link="#"
            authors={
              <>
                A. Smith, <span className="highlight">Prof. Dr. Mustafa Zaman</span>, J. Doe
              </>
            }
            journal="Journal of Nephrology — Vol.12"
            pubdate="Published: Mar 15, 2023"
          />
        </div>
        <div className="center left">
          <span className="dot-left"></span>
        </div>
        <div className="right"></div>

        {/* Right card */}
        <div className="left"></div>
        <div className="center right">
          <span className="dot-right"></span>
        </div>
        <div className="right">
          <PublicationCard
            title="Advances in Interventional Nephrology"
            link="#"
            authors={
              <>
                L. Khan, <span className="highlight">Prof. Dr. Mustafa Zaman</span>
              </>
            }
            journal="International Journal of Medicine — Vol.8"
            pubdate="Published: Jul 7, 2023"
          />
        </div>
      </div>
    </div>
  );
};

export default Publications;
